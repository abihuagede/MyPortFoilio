import { textAnimation } from './textAnimation.js';
import anime from 'https://cdn.jsdelivr.net/npm/animejs@3.2.1/+esm';

document.addEventListener('DOMContentLoaded', () => {
  // Hero text animation
  const heroHeading = document.querySelector('#hero h1');
  if (heroHeading) {
    textAnimation(heroHeading, 'fadeInUp', 1000);
  }

  const heroParagraph = document.querySelector('#hero p');
  if (heroParagraph) {
    textAnimation(heroParagraph, 'fadeInUp', 1500);
  }

  // Observe sections for fade-in animation on scroll
  const sections = document.querySelectorAll('section');
  const fadeIn = (element, delay) => {
    anime({
      targets: element,
      opacity: 1,
      translateY: [50, 0],
      duration: 1000,
      easing: 'easeOutExpo',
      delay: delay,
    });
  };

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          fadeIn(entry.target, 200);
          observer.unobserve(entry.target); // Stop observing after fade-in
        }
      });
    },
    {
      threshold: 0.2, // Trigger when 20% of the section is visible
    }
  );

  sections.forEach((section) => {
    section.style.opacity = 0; // Initially hide the sections
    observer.observe(section);
  });

  // Contact Form Submission (basic)
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      alert('Form submission is simulated.  Please connect via email!');
    });
  }
});