import anime from 'https://cdn.jsdelivr.net/npm/animejs@3.2.1/+esm';

export function textAnimation(element, animationName, delay) {
  anime({
    targets: element,
    opacity: [0, 1],
    translateY: [-50, 0],
    duration: 1500,
    delay: delay,
    easing: 'easeOutExpo',
  });
}